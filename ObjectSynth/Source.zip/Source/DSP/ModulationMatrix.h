#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>

enum class ModDestination {
    None,
    LPCutoff,
    HPCutoff,
    BPCutoff,
    Count
};


struct ModulationRoute {
    ModDestination destination = ModDestination::None;
    float depth = 0.0f;
};


class ModulationMatrix final {
public:
    static constexpr std::size_t maxRoutes = 4;

    static constexpr std::size_t destinationCount = static_cast<std::size_t>(ModDestination::Count);

    using Values = std::array<float, destinationCount>;

    void setRoute(std::size_t slot, ModulationRoute route) noexcept {

        if (slot >= routes.size() || !std::isfinite(route.depth))
            return;

        if (static_cast<std::size_t>(route.destination) >= destinationCount)
            return;

        route.depth = std::clamp(route.depth, -1.0f, 1.0f);
        routes[slot] = route;
    }

    Values evaluate(float lfoValue) const noexcept {
        Values result{};

        const float source = std::isfinite(lfoValue) ? std::clamp(lfoValue, -1.0f, 1.0f) : 0.0f;

        for (const auto& route : routes){
            const auto index = static_cast<std::size_t>(route.destination);

            if (index > 0 && index < result.size())
                result[index] += route.depth * source;
        }

        for (auto& value : result)
            value = std::clamp(value, -1.0f, 1.0f);

        return result;
    }

private:
    std::array<ModulationRoute, maxRoutes> routes{};
};
